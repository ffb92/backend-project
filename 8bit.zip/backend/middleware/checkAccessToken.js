import { getAccessToken, getToken } from './auth.js';

// Middleware zum Überprüfen und Aktualisieren des Access Tokens
const checkAccessToken = async (req, res, next) => {
  if (!getToken()) {
    try {
      await getAccessToken();
    } catch (error) {
      console.error('Error fetching access token:', error);
      return res.status(500).send('Error fetching access token');
    }
  }
  next();
};

export default checkAccessToken;