import https from 'https';
import querystring from 'querystring';
import dotenv from 'dotenv';

dotenv.config({ path: './config.env' });

let accessToken = '';

export const getAccessToken = () => {
  return new Promise((resolve, reject) => {
    const postData = querystring.stringify({
      client_id: process.env.CLIENT_ID,
      client_secret: process.env.CLIENT_SECRET,
      grant_type: 'client_credentials',
    });

    const options = {
      hostname: 'id.twitch.tv',
      path: '/oauth2/token',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': postData.length,
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        if (res.statusCode === 200) {
          accessToken = JSON.parse(data).access_token;
          console.log('Access Token:', accessToken);
          resolve();
        } else {
          console.error('Failed to fetch access token, Status Code:', res.statusCode);
          console.error('Response:', data);
          reject(new Error('Failed to fetch access token'));
        }
      });
    });

    req.on('error', (e) => {
      console.error('Request error:', e);
      reject(e);
    });

    req.write(postData);
    req.end();
  });
};

export const getToken = () => accessToken;