import https from 'https';
import { getToken } from '../middleware/auth.js';

export const fetchFromIGDB = (endpoint, query) => {
  return new Promise((resolve, reject) => {
    const postData = query;
    const options = {
      hostname: 'api.igdb.com',
      path: `/v4/${endpoint}`,
      method: 'POST',
      headers: {
        'Client-ID': process.env.CLIENT_ID,
        Authorization: `Bearer ${getToken()}`,
        Accept: 'application/json',
        'Content-Type': 'text/plain',
        'Content-Length': postData.length,
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        if (res.statusCode === 200) {
          resolve(JSON.parse(data));
        } else {
          reject(new Error('Failed to fetch data from IGDB'));
        }
      });
    });

    req.on('error', (e) => {
      reject(e);
    });

    req.write(postData);
    req.end();
  });
};
