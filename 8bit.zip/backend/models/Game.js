import mongoose from 'mongoose';

const gameSchema = new mongoose.Schema({
  id: Number,
  name: String,
  slug: String,
  rank: Number // Füge ein Feld für das Ranking hinzu
});

const Game = mongoose.model('Game', gameSchema);

export default Game;