import express from 'express';
import {
  importGames,
  getAllGames,
  createGame,
  updateGame,
  deleteGame,
} from '../controllers/gameController.js';

const router = express.Router();

// Beispiel-Route zum Abrufen und Speichern von Games
router.post('/', importGames);

// Route zum Abrufen aller Spiele
router.get('/', getAllGames);

// Route zum Erstellen eines neuen Spiels
router.post('/create', createGame);

// Route zum Aktualisieren eines Spiels
router.put('/:id', updateGame);

// Route zum Löschen eines Spiels
router.delete('/:id', deleteGame);

export default router;